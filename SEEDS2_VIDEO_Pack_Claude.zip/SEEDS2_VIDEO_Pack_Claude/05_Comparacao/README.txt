Nesta pasta está a comparação visual da importação no PCC entre o caso A e o caso B.
Legenda do gráfico enviado pelo usuário:
- A = linha cheia
- B = linha tracejada
Uso recomendado: como referência visual/narrativa, não como único insumo numérico.
